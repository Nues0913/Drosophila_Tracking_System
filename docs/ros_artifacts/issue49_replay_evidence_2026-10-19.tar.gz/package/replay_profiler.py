#!/usr/bin/env python3
"""Bounded offline sensor-bag replay for GitHub Issue #49 (no Gazebo)."""
from __future__ import annotations

import argparse
import json
import os
import signal
import subprocess
import sys
import time
import uuid
from pathlib import Path

import rosbag2_py
import rclpy
from flytrack_interfaces.msg import ControlTrace, OdorReading, ScenarioEvent
from geometry_msgs.msg import Twist
from rclpy.executors import SingleThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from rclpy.serialization import deserialize_message
from rosgraph_msgs.msg import Clock
from rosidl_runtime_py.utilities import get_message
from sensor_msgs.msg import Image
from std_srvs.srv import Trigger

ROOT = Path("/workspace")
ARTIFACT = ROOT / "artifacts/issue22_smoke"
BAG = ROOT / "runs/ros_validation/issue22_83f57d1/multi5/bags/flytrack_20261019T031946_320499Z"
SENSORS = {
    "/fly/camera/left/image_raw": (Image, "left"),
    "/fly/camera/right/image_raw": (Image, "right"),
    "/fly/odor": (OdorReading, "odor"),
}
INPUT_TOPICS = ["/clock", "/world/scenario", *SENSORS]


def stamp_pair(header):
    return [int(header.stamp.sec), int(header.stamp.nanosec)]


def write_json(stream, obj):
    stream.write(json.dumps(obj, sort_keys=True, separators=(",", ":")) + "\n")


class ReplayMonitor(Node):
    def __init__(self, output: Path):
        super().__init__("issue49_bag_replay_controller")
        self.output = output.open("x", encoding="utf-8")
        self.spin_exec = SingleThreadedExecutor()
        self.spin_exec.add_node(self)
        self.phase = "setup"
        self.current_clock = Clock()
        self.trace_count = 0
        self.command_count = 0
        self.reset_count = 0
        self.trace_sequences = []
        self.topic_publish_counts = {topic: 0 for topic in INPUT_TOPICS}
        self.command_receive_count = 0
        self._record_count = 0

        clock_qos = QoSProfile(depth=10, reliability=ReliabilityPolicy.BEST_EFFORT)
        camera_qos = QoSProfile(depth=2, reliability=ReliabilityPolicy.BEST_EFFORT)
        odor_qos = QoSProfile(depth=5, reliability=ReliabilityPolicy.BEST_EFFORT)
        trace_qos = QoSProfile(depth=256, reliability=ReliabilityPolicy.RELIABLE)
        cmd_qos = QoSProfile(depth=16, reliability=ReliabilityPolicy.RELIABLE)
        self.clock_pub = self.create_publisher(Clock, "/clock", clock_qos)
        self.camera_pubs = {
            topic: self.create_publisher(Image, topic, camera_qos)
            for topic in ("/fly/camera/left/image_raw", "/fly/camera/right/image_raw")
        }
        self.odor_pub = self.create_publisher(OdorReading, "/fly/odor", odor_qos)
        self.reset_client = self.create_client(Trigger, "/connectome_policy_node/reset")
        self.create_subscription(ControlTrace, "/fly/control_trace", self._on_trace, trace_qos)
        self.create_subscription(Twist, "/cmd_vel", self._on_command, cmd_qos)
        self.write(
            {
                "event": "monitor_start",
                "host_monotonic_ns": time.monotonic_ns(),
                "ros_domain_id": os.environ.get("ROS_DOMAIN_ID"),
            }
        )

    def write(self, record):
        self._record_count += 1
        write_json(self.output, record)
        if self._record_count % 128 == 0:
            self.output.flush()

    def _on_trace(self, message):
        self.trace_count += 1
        self.trace_sequences.append(int(message.command_sequence))
        self.write(
            {
                "event": "control_trace",
                "phase": self.phase,
                "receive_monotonic_ns": time.monotonic_ns(),
                "command_sequence": int(message.command_sequence),
                "sim_stamp": stamp_pair(message.header),
                "clock_domain": message.clock_domain,
                "valid": [bool(x) for x in message.valid],
                "policy_received_monotonic_ns": [int(x) for x in message.policy_received_monotonic_ns],
                "control_started_monotonic_ns": int(message.control_started_monotonic_ns),
                "command_published_monotonic_ns": int(message.command_published_monotonic_ns),
                "samples": [
                    {
                        "sensor": sample.sensor,
                        "header_stamp": stamp_pair(sample.header),
                        "source_monotonic_ns": int(sample.source_monotonic_ns),
                    }
                    for sample in message.samples
                ],
            }
        )
        self.output.flush()

    def _on_command(self, message):
        self.command_receive_count += 1
        self.write(
            {
                "event": "cmd_vel",
                "phase": self.phase,
                "receive_monotonic_ns": time.monotonic_ns(),
                "linear_x": float(message.linear.x),
                "angular_z": float(message.angular.z),
            }
        )
        self.output.flush()

    def wait_for_policy(self, process, timeout_s=45):
        end = time.monotonic() + timeout_s
        while not self.reset_client.wait_for_service(timeout_sec=0.1):
            self.spin_exec.spin_once(timeout_sec=0.01)
            if process.poll() is not None:
                raise RuntimeError(f"policy process exited during startup: {process.returncode}")
            if time.monotonic() >= end:
                raise TimeoutError("policy reset service did not become available")
        # Allow DDS discovery for sensor and monitor subscriptions.
        end = time.monotonic() + 0.5
        while time.monotonic() < end:
            self.spin_exec.spin_once(timeout_sec=0.01)
        self.write({"event": "policy_ready", "host_monotonic_ns": time.monotonic_ns()})

    def reset_before_episode(self, event):
        phase = json.loads(event.parameters_json).get("phase")
        if phase != "resetting":
            return
        request_start_ns = time.monotonic_ns()
        request = Trigger.Request()
        future = self.reset_client.call_async(request)
        deadline = time.monotonic() + 5
        while not future.done():
            self.spin_exec.spin_once(timeout_sec=0.01)
            if time.monotonic() >= deadline:
                raise TimeoutError(f"policy reset timed out for episode {event.episode_id}")
        response = future.result()
        self.reset_count += 1
        record = {
            "event": "reset_ack",
            "phase": self.phase,
            "episode_id": int(event.episode_id),
            "scenario_phase": phase,
            "event_sim_stamp": stamp_pair(event.header),
            "request_start_monotonic_ns": request_start_ns,
            "response_monotonic_ns": time.monotonic_ns(),
            "success": bool(response.success),
            "message": response.message,
        }
        self.write(record)
        if not response.success:
            raise RuntimeError(f"policy reset failed: {response.message}")

    def replay(self, label: str, duration_s: float | None):
        self.phase = label
        first_record_ns = None
        start_monotonic_ns = time.monotonic_ns()
        self.write(
            {
                "event": "phase_start",
                "phase": label,
                "host_monotonic_ns": start_monotonic_ns,
                "duration_limit_s": duration_s,
            }
        )
        reader = rosbag2_py.SequentialReader()
        reader.open(
            rosbag2_py.StorageOptions(uri=str(BAG), storage_id="sqlite3"),
            rosbag2_py.ConverterOptions(
                input_serialization_format="cdr", output_serialization_format="cdr"
            ),
        )
        topic_types = {item.name: item.type for item in reader.get_all_topics_and_types()}
        message_types = {topic: get_message(topic_types[topic]) for topic in INPUT_TOPICS}
        reader.set_filter(rosbag2_py.StorageFilter(topics=INPUT_TOPICS))
        first_message = True
        while reader.has_next():
            topic, payload, record_ns = reader.read_next()
            if first_record_ns is None:
                first_record_ns = int(record_ns)
                start_monotonic_ns = time.monotonic_ns()
            elapsed_bag_ns = int(record_ns) - first_record_ns
            if duration_s is not None and elapsed_bag_ns > duration_s * 1e9:
                break
            target_ns = start_monotonic_ns + elapsed_bag_ns
            while True:
                remaining_ns = target_ns - time.monotonic_ns()
                if remaining_ns <= 0:
                    break
                self.executor.spin_once(timeout_sec=min(remaining_ns / 1e9, 0.01))
            message = deserialize_message(payload, message_types[topic])
            self.topic_publish_counts[topic] += 1
            if topic == "/world/scenario":
                self.reset_before_episode(message)
            elif topic == "/clock":
                self.current_clock = message
                self.clock_pub.publish(message)
            else:
                self.write(
                    {
                        "event": "sensor_publish",
                        "phase": label,
                        "sensor": SENSORS[topic][1],
                        "header_stamp": stamp_pair(message.header),
                        "publish_monotonic_ns": time.monotonic_ns(),
                    }
                )
                if topic == "/fly/odor":
                    self.odor_pub.publish(message)
                else:
                    self.camera_pubs[topic].publish(message)
            if first_message:
                first_message = False
            self.spin_exec.spin_once(timeout_sec=0)
        end_ns = time.monotonic_ns()
        self.write(
            {
                "event": "phase_end",
                "phase": label,
                "host_monotonic_ns": end_ns,
                "elapsed_host_s": (end_ns - start_monotonic_ns) / 1e9,
                "topic_counts_cumulative": self.topic_publish_counts,
                "reset_count_cumulative": self.reset_count,
            }
        )
        if first_record_ns is None:
            raise RuntimeError("bag replay published no messages")
        return (end_ns - start_monotonic_ns) / 1e9

    def drain_pending_traces(self, duration_s=1.4):
        self.phase = "drain"
        start_ns = time.monotonic_ns()
        self.write({"event": "phase_start", "phase": "drain", "host_monotonic_ns": start_ns})
        clock_ns = int(self.current_clock.clock.sec) * 1_000_000_000 + int(
            self.current_clock.clock.nanosec
        )
        step_ns = 50_000_000
        count = int(duration_s / 0.05)
        for _ in range(count):
            clock_ns += step_ns
            self.current_clock.clock.sec, remainder = divmod(clock_ns, 1_000_000_000)
            self.current_clock.clock.nanosec = remainder
            self.clock_pub.publish(self.current_clock)
            target = time.monotonic() + 0.05
            while time.monotonic() < target:
                self.spin_exec.spin_once(timeout_sec=min(target - time.monotonic(), 0.01))
        self.write(
            {
                "event": "phase_end",
                "phase": "drain",
                "host_monotonic_ns": time.monotonic_ns(),
                "clock_steps": count,
            }
        )

    def close(self):
        self.write(
            {
                "event": "monitor_end",
                "host_monotonic_ns": time.monotonic_ns(),
                "trace_count": self.trace_count,
                "command_receive_count": self.command_receive_count,
                "reset_count": self.reset_count,
                "trace_sequence_min": min(self.trace_sequences) if self.trace_sequences else None,
                "trace_sequence_max": max(self.trace_sequences) if self.trace_sequences else None,
                "topic_publish_counts": self.topic_publish_counts,
            }
        )
        self.output.flush()
        self.output.close()
        self.spin_exec.remove_node(self)
        self.destroy_node()


def run_case(device: str, profile: bool, base_output: Path, index: int, preflight_only=False):
    case = f"{device}-{'profile_on' if profile else 'profile_off'}"
    output = base_output / case
    output.mkdir(parents=True, exist_ok=False)
    profiler_path = output / "profiler.jsonl"
    policy_log_path = output / "policy.log"
    monitor_path = output / "monitor.jsonl"
    domain_id = int(os.environ["ROS_DOMAIN_ID"])
    policy_entrypoint = os.environ.get(
        "POLICY_ENTRYPOINT",
        f"/tmp/issue49-{device}-install/flytrack_policy/lib/flytrack_policy/connectome_policy_node",
    )
    args = [
        "/opt/flytrack-ros/bin/python3",
        policy_entrypoint,
        "--ros-args",
        "-p",
        "use_sim_time:=true",
        "-p",
        f"artifact:={ARTIFACT}",
        "-p",
        f"sensor_contract_json:={ARTIFACT / 'sensor_contract.json'}",
        "-p",
        f"device:={device}",
        "-p",
        f"profiler_enabled:={'true' if profile else 'false'}",
        "-p",
        f"profiler_output_path:={profiler_path if profile else output / 'profiler-disabled.jsonl'}",
    ]
    with policy_log_path.open("w", encoding="utf-8") as log:
        process = subprocess.Popen(args, stdout=log, stderr=subprocess.STDOUT, env=os.environ.copy())
        monitor = ReplayMonitor(monitor_path)
        try:
            monitor.write(
                {
                    "event": "case_metadata",
                    "case": case,
                    "device": device,
                    "profiler_enabled": profile,
                    "ros_domain_id": domain_id,
                    "policy_pid": process.pid,
                    "host_monotonic_ns": time.monotonic_ns(),
                    "main_commit": "1563a936bc75f4db2e82e1c9c9df3fd6b0929a13",
                    "artifact_model_card_sha256": "7ccff60ad0620b4ec5275eba48f1d8a8aece59d6b73a8594d93fdd69360f5fdc",
                    "contract_sha256": "a78efde40508d298f2f1af444e163f0f9b7e46efb12158a642a159d8934dc5d5",
                    "bag_db3_sha256": "1d25294bb78123590167a51fbdebb70a3a600db49f54af0140ce11c820b60c92",
                }
            )
            monitor.wait_for_policy(process)
            replay_start = time.monotonic_ns()
            warm_duration = monitor.replay("warmup", 10.0)
            monitor.drain_pending_traces()
            warmup_end = time.monotonic_ns()
            monitor.write(
                {
                    "event": "warmup_complete",
                    "host_monotonic_ns": warmup_end,
                    "warmup_replay_s": warm_duration,
                }
            )
            if preflight_only:
                replay_end = time.monotonic_ns()
                monitor.write(
                    {
                        "event": "preflight_complete",
                        "case": case,
                        "host_monotonic_ns": replay_end,
                        "warmup_replay_s": warm_duration,
                    }
                )
                monitor.output.flush()
                process.send_signal(signal.SIGINT)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    process.kill()
                    raise TimeoutError("policy did not stop cleanly after preflight")
                if process.returncode not in (0, 130, -signal.SIGINT):
                    raise RuntimeError(f"policy exited with {process.returncode}; see {policy_log_path}")
                return (replay_end - replay_start) / 1e9
            measured_duration = monitor.replay("measurement", None)
            monitor.drain_pending_traces()
            replay_end = time.monotonic_ns()
            elapsed = (replay_end - replay_start) / 1e9
            monitor.write(
                {
                    "event": "case_complete",
                    "case": case,
                    "host_monotonic_ns": replay_end,
                    "warmup_plus_measurement_and_drain_s": elapsed,
                    "measured_bag_replay_s": measured_duration,
                }
            )
            if elapsed > 600:
                raise TimeoutError(f"{device} paired replay exceeded 600 s: {elapsed:.2f}")
            process.send_signal(signal.SIGINT)
            try:
                process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                process.kill()
                raise TimeoutError("policy did not stop cleanly after replay")
            if process.returncode not in (0, 130, -signal.SIGINT):
                raise RuntimeError(f"policy exited with {process.returncode}; see {policy_log_path}")
            return elapsed
        except Exception:
            if process.poll() is None:
                process.send_signal(signal.SIGINT)
                try:
                    process.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.wait(timeout=2)
            raise
        finally:
            monitor.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--device", choices=("cpu", "cuda"), required=True)
    parser.add_argument("--output", type=Path, default=ROOT / "runs/issue49_profiler")
    parser.add_argument("--preflight-only", action="store_true")
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    if args.device == "cuda":
        import torch

        if not torch.cuda.is_available():
            raise RuntimeError("CUDA is not available in this container")
        if torch.cuda.get_device_name(0) != "NVIDIA GeForce RTX 4070 Laptop GPU":
            raise RuntimeError(f"unexpected GPU: {torch.cuda.get_device_name(0)}")
    group_start_ns = time.monotonic_ns()
    group_dir = args.output / f"{args.device}-{time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())}"
    group_dir.mkdir(parents=True, exist_ok=False)
    if args.preflight_only:
        elapsed = run_case(args.device, False, group_dir, 0, preflight_only=True)
        print(f"PREFLIGHT_COMPLETE device={args.device} elapsed_s={elapsed:.3f} output={group_dir}")
        return
    run_case(args.device, False, group_dir, 0)
    run_case(args.device, True, group_dir, 1)
    group_elapsed = (time.monotonic_ns() - group_start_ns) / 1e9
    if group_elapsed > 600:
        raise TimeoutError(f"{args.device} paired cases exceeded 600 s: {group_elapsed:.2f}")
    (group_dir / "group-summary.json").write_text(
        json.dumps(
            {
                "device": args.device,
                "group_elapsed_s_including_startup": group_elapsed,
                "limit_s": 600,
                "cases": ["profile_off", "profile_on"],
            },
            indent=2,
            sort_keys=True,
        )
        + "\n",
        encoding="utf-8",
    )
    print(f"GROUP_COMPLETE device={args.device} elapsed_s={group_elapsed:.3f} output={group_dir}")


if __name__ == "__main__":
    rclpy.init()
    try:
        main()
    finally:
        rclpy.shutdown()
