Issue #49 bounded replay evidence

Fixed source main: 1563a936bc75f4db2e82e1c9c9df3fd6b0929a13
Host GPU: NVIDIA GeForce RTX 4070 Laptop GPU, 8188 MiB, driver 617.42
Container: flytrack-ros:issue22-gpu-cu126
Container image ID: sha256:792f9b3d4f09717020c33268ce379ff29a250cc81906d6d3881e3908a4aca39c
ROS_DOMAIN_ID: CPU 181, CUDA 182 (separate runs)

The four raw run directories contain the monitor JSONL and policy logs. The two profile-on directories also contain the full profiler JSONL sidecar. CPU preflight files contain a successful 10 s startup/reset/fresh-input check; they are not part of the CPU profile-off/on comparison. Failed startup attempts before bag playback are not included here. They did not start a training process or replay the bag.

The replay harness is included as replay_profiler.py. It starts the fixed-main ROS policy executable from the deployed Python environment, replays the original input bag at recorded receive-time spacing, sends each recorded /clock and sensor sample, calls policy reset for every ScenarioEvent marked resetting, and drains delayed callbacks after each pass. It does not replay old /fly/sensor_timing, /fly/control_trace, /cmd_vel, or truth outputs. Old CLOCK_MONOTONIC values were not used in calculations.

The policy profiler sidecar records every command sequence as status=emitted, but the independent ControlTrace subscriber did not receive every sequence. Missing sequences cluster at episode reset boundaries. Because the replay did not provide /fly/sensor_timing, pending traces were cleared by reset; therefore status=emitted must not be interpreted as independent confirmation of delivery. This limitation is fully described in the report and was not addressed by another replay.

Input hashes:
- Bag DB3: 1d25294bb78123590167a51fbdebb70a3a600db49f54af0140ce11c820b60c92
- Bag metadata.yaml: e34ed68595c4021ff078763a34ebd1ab73f07d54a5356793b3252331dce46912
- model_card.json: 7ccff60ad0620b4ec5275eba48f1d8a8aece59d6b73a8594d93fdd69360f5fdc
- sensor_contract.json: a78efde40508d298f2f1af444e163f0f9b7e46efb12158a642a159d8934dc5d5
- frontend.npz: 47cccf33ad8a5ba708d557e500cf48b7f3946be1b0f9f6eecffec6349955ec69
- graph.npz: a3c70c2759b0c9af179bb40ef0ff6e46ff469c96df0155c8fbe82bc4715f2e71
- weights.pt: 8a35664fca681b55022b27d3303ea6aff46eedb71d76eb40247ac7933f58acb3

Original bag and model artifact are not duplicated in this package. Their hashes above identify the inputs used.
