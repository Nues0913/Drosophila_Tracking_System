#!/bin/bash
set -eo pipefail

# Host: WSL2. Each invocation was one Docker container; the second build path is mounted at /workspace.
DOCKER='/mnt/c/Program Files/Docker/Docker/resources/bin/docker.exe'
IMAGE='flytrack-ros:issue22-gpu-cu126'
MOUNT='C:\Users\weiti\AppData\Local\Temp\flytrack-issue49-context-1563\workspace:/workspace'

# CPU paired pass, ROS_DOMAIN_ID=181
"$DOCKER" run --rm --gpus all --env ROS_DOMAIN_ID=181 --env PYTHONUNBUFFERED=1 --env PYTHONPATH=/workspace/python --env POLICY_ENTRYPOINT=/tmp/issue49-cpu-install/flytrack_policy/lib/flytrack_policy/connectome_policy_node -v "$MOUNT" --entrypoint bash "$IMAGE" -lc 'set -eo pipefail; source /opt/ros/lyrical/setup.bash; cd /workspace/ros2_ws; colcon --log-base /tmp/issue49-cpu-log build --symlink-install --build-base /tmp/issue49-cpu-build --install-base /tmp/issue49-cpu-install --cmake-args -DPython3_EXECUTABLE=/opt/flytrack-ros/bin/python3; source /tmp/issue49-cpu-install/setup.bash; python3 /workspace/replay_profiler.py --device cpu --output /workspace/runs/issue49_profiler'

# CUDA paired pass, ROS_DOMAIN_ID=182
"$DOCKER" run --rm --gpus all --env ROS_DOMAIN_ID=182 --env PYTHONUNBUFFERED=1 --env PYTHONPATH=/workspace/python --env POLICY_ENTRYPOINT=/tmp/issue49-gpu-install/flytrack_policy/lib/flytrack_policy/connectome_policy_node -v "$MOUNT" --entrypoint bash "$IMAGE" -lc 'set -eo pipefail; source /opt/ros/lyrical/setup.bash; cd /workspace/ros2_ws; colcon --log-base /tmp/issue49-gpu-log build --symlink-install --build-base /tmp/issue49-gpu-build --install-base /tmp/issue49-gpu-install --cmake-args -DPython3_EXECUTABLE=/opt/flytrack-ros/bin/python3; source /tmp/issue49-gpu-install/setup.bash; python3 /workspace/replay_profiler.py --device cuda --output /workspace/runs/issue49_profiler'
